#!/usr/bin/env python3

import json
from sys import argv


if len(argv) not in [3, 4]:
    print('Usage: max_time_arbiter.py labels1.json labels2.json [output.json]')
    exit(1)

if 'label' in argv[1]:
    with open(argv[1], 'r') as f:
        labels1 = json.load(f)
else:
    print('Expected label file, not {}'.format(argv[1]))
    exit(1)

if 'label' in argv[2]:
    with open(argv[2], 'r') as f:
        labels2 = json.load(f)
else:
    print('Expected label file, not {}'.format(argv[2]))
    exit(1)

newlabels = []
    
# This makes heavy assumptions about how the events in the files line
# up between the testers, and really this should be replaced with
# something more robust.
if len(labels1) != len(labels2):
    print('Error: event count mismatch:', len(labels1), len(labels2))
    exit(1)

for event1, event2 in zip(labels1, labels2):
    if (
            event1['endTime'] < event2['time'] or
            event2['endTime'] < event1['time']):
        print('Error: events don\'t overlap')
        print(event1)
        print(event2)
        continue

    if event1['id'] != event2['id']:
        print('Warning: matched events have different id\'s')
        print(event1)
        print(event2)
        print('FYI, keeping id {} from event1'.format(event1['id']))

    if event1['type'] != event2['type']:
        print('Error: events disagree on type')
        print(event1)
        print(event2)
        continue

    dur1 = event1['endTime'] - event1['time']
    dur2 = event2['endTime'] - event2['time']
    durthresh = 0.1  # 10% difference in time for warning
    diff = 2 * abs(dur1 - dur2) / (dur1 + dur2)
    if diff > durthresh:
        print('Warning: event times differ by {}%,'.format(round(100*diff, 1)),
              'which is more than {}%'.format(100*durthresh))
        print(event1)
        print(event2)

    newevent = {'time': min(event1['time'], event2['time']),
                'endTime': max(event1['endTime'], event2['endTime']),
                'id': event1['id'],
                'type': event1['type']}

    # print('New event:', newevent)
    newlabels.append(newevent)

print('Done combining, writing to file...')
with open(argv[3] if len(argv) == 4 else 'arbitrary_labels.json', 'w') as f:
    json.dump(newlabels, f, indent=4)
print('All done')
